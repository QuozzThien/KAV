// Gộp các module thành MỘT file chạy bằng bookmarklet: docs/kpa.js (+ docs/kpa.inline.txt: bookmarklet nhúng sẵn toàn bộ mã).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const version = JSON.parse(read('package.json')).version;
const FILES = ['src/shared/helpers.js', 'src/reader/contentExtractor.js', 'src/widgets/registry.js', 'src/reader/questionReader.js',
  'src/ai/promptBuilder.js', 'src/ai/responseParser.js', 'src/renderer/suggestionPanel.js', 'src/transport/bookmarklet.js', 'src/content.js'];
const css = read('src/content.css');
const out = [
  `/*! Khanware Practice Assistant v${version} (bookmarklet). Chỉ đọc câu hỏi và hiển thị gợi ý; không chọn/điền/nộp bài. Tạo bởi scripts/build.js, đừng sửa tay. */`,
  '(function () {', "'use strict';",
  "if (!window.__KPA_TEST__ && !/(^|\\.)khanacademy\\.org$/i.test(location.hostname)) { alert('Công cụ này chỉ chạy trên khanacademy.org'); return; }",
  "if (window.__KPA_LOADED__) { if (window.__KPA_OPEN__) window.__KPA_OPEN__(); return; } // bấm lần nữa: chỉ mở bảng",
  '{ const st = document.createElement("style"); st.id = "kpa-style"; st.textContent = ' + JSON.stringify(css) + '; document.head.appendChild(st); }',
  ...FILES.map(f => `/* ---- ${f} ---- */\n` + read(f)),
  '})();', ''
].join('\n');
fs.mkdirSync(path.join(root, 'docs'), { recursive: true });
fs.writeFileSync(path.join(root, 'docs/kpa.js'), out);
fs.writeFileSync(path.join(root, 'docs/kpa.inline.txt'), 'javascript:' + encodeURIComponent(out));
console.log('docs/kpa.js', out.length, 'bytes; inline bookmarklet', ('javascript:' + encodeURIComponent(out)).length, 'chars');
