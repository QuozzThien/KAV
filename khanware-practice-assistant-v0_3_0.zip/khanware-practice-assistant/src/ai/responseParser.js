/* Phân tích + kiểm tra phản hồi AI. Không tin tưởng đầu ra: mọi chỉ số phải hợp lệ theo dữ liệu đã đọc. */
(function (root) {
  const K = root.KPA || (root.KPA = {});

  function extractJson(text) {
    let s = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try { return JSON.parse(s); } catch (_) {}
    const start = s.indexOf('{'); if (start < 0) throw new Error('Không có JSON trong phản hồi AI.');
    let depth = 0, inStr = false, esc = false;
    for (let i = start; i < s.length; i++) {
      const c = s[i];
      if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
      if (c === '"') inStr = true; else if (c === '{') depth++; else if (c === '}' && --depth === 0) {
        try { return JSON.parse(s.slice(start, i + 1)); } catch (_) { break; }
      }
    }
    throw new Error('AI trả về JSON không hợp lệ.');
  }
  function normConfidence(c) { // chấp nhận số 0..1, 0..100, chuỗi số hoặc nhãn
    if (typeof c === 'number' && isFinite(c)) return Math.min(1, Math.max(0, c > 1 ? c / 100 : c));
    if (typeof c === 'string' && c.trim() !== '' && isFinite(Number(c))) return normConfidence(Number(c));
    const m = { high: .85, medium: .55, low: .25, cao: .85, 'trung bình': .55, thấp: .25 };
    return typeof c === 'string' && m[c.toLowerCase()] != null ? m[c.toLowerCase()] : null;
  }

  function validate(obj, exercise) {
    if (!obj || typeof obj !== 'object' || !Array.isArray(obj.answers)) return { ok: false, errors: ['Thiếu mảng "answers".'] };
    const REG = K.widgets.REGISTRY, results = [], errors = [];
    let needsMoreInfo = !!obj.needsMoreInfo;
    for (const w of exercise.widgets) {
      const a = obj.answers.find(x => x && x.widgetId === w.id);
      if (!a) { errors.push(w.id + ': thiếu đáp án'); continue; }
      if (a.status === 'insufficient_data') { needsMoreInfo = true; results.push({ widgetId: w.id, type: w.type, insufficient: true, lines: [], marks: [] }); continue; }
      const v = REG[w.type].validate(a.answer, w.data);
      if (v.error) { errors.push(w.id + ' (' + w.type + '): ' + v.error); continue; }
      const d = REG[w.type].describe(v.value, w.data);
      results.push({ widgetId: w.id, type: w.type, lines: d.lines, marks: d.marks, table: d.table, experimental: w.experimental });
    }
    if (errors.length) return { ok: false, errors };
    return { ok: true, results, explanation: String(obj.explanation || '').slice(0, 3000), confidence: normConfidence(obj.confidence), needsMoreInfo };
  }

  K.responseParser = { extractJson, validate, normConfidence };
  if (typeof module === 'object' && module.exports) module.exports = K.responseParser;
})(globalThis);
