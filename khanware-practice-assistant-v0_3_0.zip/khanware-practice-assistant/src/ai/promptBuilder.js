/* Dựng prompt từ JSON đã chuẩn hóa. Mỗi widget kèm định dạng đáp án riêng (lấy từ registry). */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const MAX_USER_CHARS = 12000;
  const SYSTEM = [
    'You are a careful tutor helping a student check their own practice work. The student will decide what to do on the page.',
    'You receive JSON describing one exercise: questionText (widgets appear as [WIDGET id: type]) and widgets[] with id, type, answerFormat and data.',
    'Solve it only from the provided data. If the data is not enough to be sure, set that widget status to "insufficient_data" instead of guessing.',
    'Return exactly ONE JSON object and nothing else:',
    '{"answers":[{"widgetId":"w1","status":"answered"|"insufficient_data","answer":<object in the widget answerFormat>}],"explanation":"<short explanation in Vietnamese>","confidence":<number 0..1>}',
    'Always refer to options/items/cells by the numeric indexes given in data. Never tell the user to click, type or submit anything automatically.'
  ].join('\n');

  function build(exercise) {
    if (!exercise || exercise.status !== 'ok') return { error: 'Câu hỏi chưa đủ điều kiện để gửi AI.' };
    const REG = K.widgets.REGISTRY;
    const payload = {
      questionText: exercise.questionText,
      widgets: exercise.widgets.map(w => ({ id: w.id, type: w.type, answerFormat: REG[w.type].format, data: w.data }))
    };
    const user = JSON.stringify(payload);
    if (user.length > MAX_USER_CHARS) return { error: 'Câu hỏi quá dài để gửi AI (' + user.length + ' ký tự, giới hạn ' + MAX_USER_CHARS + ').' };
    return { system: SYSTEM, user };
  }

  K.promptBuilder = { build, SYSTEM, MAX_USER_CHARS };
  if (typeof module === 'object' && module.exports) module.exports = K.promptBuilder;
})(globalThis);
