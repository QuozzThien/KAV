/* Kênh giao tiếp bản extension: gọi AI qua service worker (key nằm trong background, không lộ ra trang). */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const send = msg => new Promise((res, rej) => chrome.runtime.sendMessage(msg, r => (chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(r))));
  K.transport = {
    kind: 'extension',
    solve: (id, system, user) => send({ type: 'KPA_SOLVE', id, system, user }),
    abort: id => { send({ type: 'KPA_ABORT', id }).catch(() => {}); },
    openSettings: () => { send({ type: 'KPA_OPEN_OPTIONS' }).catch(() => {}); },
    getPrefs: cb => { try { chrome.storage.sync.get(['kpaTheme', 'kpaCollapsed'], v => cb(v || {})); } catch (_) { cb({}); } },
    setPrefs: p => { try { chrome.storage.sync.set({ kpaTheme: p.theme, kpaCollapsed: p.collapsed }); } catch (_) {} }
  };
})(globalThis);
