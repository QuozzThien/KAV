/* Kênh giao tiếp bản bookmarklet: gọi thẳng OpenRouter từ trang (không có service worker).
 * Key + model lưu trong localStorage của khanacademy.org => script của trang có thể đọc được. Chỉ dùng key hạn mức thấp. */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';
  const DEFAULT_MODEL = 'openrouter/free', TIMEOUT_MS = 45000, MAX_RETRIES = 2, MAX_TOKENS = 900, MAX_SYSTEM = 4000, MAX_USER = 14000;
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (_) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (_) {} }
  };
  const inflight = new Map();
  const fail = (code, error) => ({ ok: false, code, error });
  const sleep = (ms, signal) => new Promise((res, rej) => { const t = setTimeout(res, ms); signal.addEventListener('abort', () => { clearTimeout(t); rej(new Error('aborted')); }, { once: true }); });

  function statusError(status, detail) {
    const d = String(detail || '').slice(0, 200);
    if (status === 400) return { fatal: true, ...fail('bad_request', 'Yêu cầu bị từ chối (400). Model có thể không hỗ trợ định dạng yêu cầu: ' + d) };
    if (status === 401) return { fatal: true, ...fail('unauthorized', 'API key không đúng hoặc đã bị thu hồi (401).') };
    if (status === 403) return { fatal: true, ...fail('forbidden', 'Key không có quyền dùng model này hoặc nội dung bị chặn (403): ' + d) };
    if (status === 429) return fail('rate_limited', 'Đã vượt giới hạn tốc độ/hạn mức (429). Hãy đợi một lúc hoặc đổi model.');
    if (status >= 500) return fail('server_error', 'Máy chủ OpenRouter đang lỗi (' + status + '). ' + d);
    return { fatal: true, ...fail('http_error', 'Lỗi HTTP ' + status + ': ' + d) };
  }

  async function solve(id, system, user, opts) {
    opts = opts || {};
    const apiKey = store.get('kpa_apiKey', ''), model = store.get('kpa_model', '') || DEFAULT_MODEL;
    if (!apiKey) return fail('no_key', 'Chưa có OpenRouter API key. Bấm "Cài đặt API key / model".');
    if (!system || !user || system.length > MAX_SYSTEM || user.length > MAX_USER) return fail('bad_input', 'Dữ liệu câu hỏi trống hoặc quá dài.');
    const ctrl = new AbortController(); inflight.set(id, ctrl);
    let jsonMode = true, last;
    try {
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        if (ctrl.signal.aborted) return fail('aborted', 'Đã hủy yêu cầu.');
        const ac = new AbortController(); let timedOut = false;
        const onAbort = () => ac.abort(); ctrl.signal.addEventListener('abort', onAbort, { once: true });
        const timer = setTimeout(() => { timedOut = true; ac.abort(); }, TIMEOUT_MS);
        let retryAfter = 0;
        try {
          const body = { model, temperature: 0.1, max_tokens: opts.maxTokens || MAX_TOKENS, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] };
          if (jsonMode) body.response_format = { type: 'json_object' };
          const res = await fetch(ENDPOINT, { method: 'POST', signal: ac.signal, headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
          const data = await res.json().catch(() => ({}));
          if (!res.ok || (data && data.error)) {
            const status = res.ok ? Number(data.error.code) || 500 : res.status, detail = (data && data.error && data.error.message) || '';
            if (status === 400 && jsonMode && /response_format|json/i.test(detail)) { jsonMode = false; continue; }
            retryAfter = Math.min((Number(res.headers.get('retry-after')) || 0) * 1000, 5000);
            const e = statusError(status, detail); if (e.fatal) return e; last = e;
          } else {
            const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
            if (content) return { ok: true, result: content };
            last = fail('empty', 'AI không trả về nội dung.');
          }
        } catch (_) {
          if (ctrl.signal.aborted) return fail('aborted', 'Đã hủy yêu cầu.');
          last = timedOut ? fail('timeout', 'Hết thời gian chờ AI (45 giây).')
            : fail('network', 'Lỗi mạng khi gọi OpenRouter. Nếu trang chặn kết nối ra ngoài (CSP), hãy dùng bản extension.');
        } finally { clearTimeout(timer); ctrl.signal.removeEventListener('abort', onAbort); }
        if (attempt < MAX_RETRIES) { try { await sleep(retryAfter || (opts.backoffMs != null ? opts.backoffMs : 800) * 2 ** attempt, ctrl.signal); } catch (_) { return fail('aborted', 'Đã hủy yêu cầu.'); } }
      }
      return last;
    } finally { inflight.delete(id); }
  }

  let box = null; // khối cài đặt trong panel
  function openSettings(ui) {
    if (box) { box.remove(); box = null; return; }
    const mk = ui.mk; box = mk('div', { class: 'kpa-card' });
    const key = mk('input', { type: 'password', autocomplete: 'off', placeholder: 'sk-or-...', 'aria-label': 'OpenRouter API key' });
    const model = mk('input', { type: 'text', placeholder: DEFAULT_MODEL, 'aria-label': 'Model' });
    key.value = store.get('kpa_apiKey', ''); model.value = store.get('kpa_model', '') || '';
    const save = mk('button', { type: 'button', class: 'kpa-small' }, 'Lưu');
    const clear = mk('button', { type: 'button', class: 'kpa-small' }, 'Xóa key');
    box.append(mk('strong', {}, 'Cài đặt'), mk('p', { class: 'kpa-note' }, 'Key lưu trong localStorage của khanacademy.org (trang có thể đọc được). Dùng key có hạn mức thấp, không dùng chung.'), key, model, save, clear);
    save.addEventListener('click', () => {
      const k = key.value.trim(), m = model.value.trim();
      if (k && !/^sk-or-[\w-]{10,}$/.test(k)) return ui.setStatus('Key có định dạng không quen thuộc (thường bắt đầu bằng sk-or-).', 'error');
      if (m && !/^[\w.:\-\/]{1,100}$/.test(m)) return ui.setStatus('Tên model không hợp lệ.', 'error');
      store.set('kpa_apiKey', k); store.set('kpa_model', m); ui.setStatus('Đã lưu cài đặt.', 'ok');
    });
    clear.addEventListener('click', () => { store.del('kpa_apiKey'); key.value = ''; ui.setStatus('Đã xóa API key.', 'ok'); });
    ui.body.append(box);
  }

  K.transport = {
    kind: 'bookmarklet', solve, openSettings,
    abort: id => { const c = inflight.get(id); if (c) c.abort(); },
    getPrefs: cb => cb(store.get('kpa_prefs', {})),
    setPrefs: p => store.set('kpa_prefs', { kpaTheme: p.theme, kpaCollapsed: p.collapsed })
  };
})(globalThis);
