/* Đăng ký widget: mỗi loại có bộ trích xuất (extract), định dạng đáp án yêu cầu AI (format),
 * bộ kiểm tra kết quả (validate) và cách hiển thị (describe).
 * Quy ước: AI luôn trả CHỈ SỐ (0-based) thay vì chép lại chữ, để đối chiếu chắc chắn và chống bịa.
 * Widget không đọc được chính xác từ DOM => supported:false (không gọi AI, không đoán). */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const H = K.helpers, E = K.extractor;
  const vis = el => H.isVisible(el);
  const isIdx = (n, len) => Number.isInteger(n) && n >= 0 && n < len;
  const TEXT_INPUT = 'input:not([type=radio]):not([type=checkbox]):not([type=hidden]):not([type=submit]):not([type=button]):not([type=file]), textarea, [role=textbox], [contenteditable="true"]';
  const LIMITS = { opt: 300, items: 40, rows: 30, cols: 12 };

  const textInputs = c => {
    const all = [...c.querySelectorAll(TEXT_INPUT)].filter(vis);
    return all.filter(a => !all.some(b => b !== a && a.contains(b)));
  };
  const fieldLabel = el => H.clean(el.getAttribute('aria-label') ||
    (el.getAttribute('aria-labelledby') && [...el.getAttribute('aria-labelledby').split(/\s+/)].map(id => (el.ownerDocument.getElementById(id) || {}).textContent || '').join(' ')) ||
    (el.labels && el.labels[0] && el.labels[0].textContent) || el.getAttribute('placeholder') || '');
  // Phần tử chỉ có ảnh/hình không mô tả => không biết nội dung thật, không được đoán
  const blind = t => /\[(ảnh không có mô tả|hình vẽ|hình vẽ canvas)\]/.test(t);
  const unsupported = reason => ({ supported: false, reason });
  const itemsFrom = (c, sel) => [...c.querySelectorAll(sel)].filter(vis).map(el => ({ el, text: H.truncate(E.textOf(el), LIMITS.opt) })).filter(x => x.text);

  /* ---------- Trắc nghiệm ---------- */
  const radio = {
    supported: true,
    format: '{"selected":[<option index>]}  (exactly one index unless data.multiple is true)',
    extract(c) {
      const ctl = [...c.querySelectorAll('input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]')].filter(vis);
      const seen = new Set(), holders = [];
      for (const el of ctl) {
        const h = el.closest('li,label,[role=listitem]') || el.parentElement || el;
        if (!c.contains(h) || seen.has(h)) continue;
        seen.add(h); holders.push(h);
      }
      const options = holders.map((h, index) => ({ index, text: H.truncate(E.textOf(h), LIMITS.opt) }));
      if (options.length < 2 || options.some(o => !o.text || blind(o.text))) return { insufficient: 'Không đọc được đủ nội dung các phương án (có thể là phương án dạng hình ảnh).' };
      const multiple = ctl.some(el => el.type === 'checkbox' || el.getAttribute('role') === 'checkbox');
      return { data: { multiple, options }, refs: holders };
    },
    validate(a, d) {
      const s = a && a.selected;
      if (!Array.isArray(s) || !s.length || !s.every(i => isIdx(i, d.options.length)) || new Set(s).size !== s.length) return { error: 'selected không hợp lệ' };
      if (!d.multiple && s.length !== 1) return { error: 'câu chỉ có một đáp án nhưng AI trả nhiều' };
      return { value: { selected: s } };
    },
    describe: (v, d) => ({ lines: v.selected.map(i => 'Phương án ' + (i + 1) + ': ' + d.options[i].text), marks: v.selected })
  };

  /* ---------- Dropdown ---------- */
  const dropdown = {
    supported: true,
    format: '{"selected": <option index>}',
    extract(c) {
      const sel = c.querySelector('select');
      let opts = [], refs = [];
      if (sel) {
        const list = [...sel.options].filter((o, i) => !(i === 0 && (o.value === '' || o.disabled)));
        opts = list.map(o => H.clean(o.textContent)); refs = [sel];
      } else {
        const btn = c.querySelector('[role=combobox],button[aria-haspopup]');
        if (!btn || btn.getAttribute('aria-expanded') !== 'true') return { insufficient: 'Danh sách thả xuống đang đóng. Hãy mở danh sách rồi bấm phân tích lại.' };
        refs = [...c.ownerDocument.querySelectorAll('[role=listbox] [role=option]')].filter(vis);
        opts = refs.map(o => E.textOf(o));
      }
      if (opts.length < 2 || opts.some(t => !t || blind(t))) return { insufficient: 'Không đọc được các lựa chọn của danh sách.' };
      return { data: { options: opts.map((text, index) => ({ index, text: H.truncate(text, LIMITS.opt) })) }, refs: sel ? [] : refs };
    },
    validate(a, d) { return isIdx(a && a.selected, d.options.length) ? { value: { selected: a.selected } } : { error: 'selected không hợp lệ' }; },
    describe: (v, d) => ({ lines: ['Chọn: ' + d.options[v.selected].text], marks: [v.selected] })
  };

  /* ---------- Ô nhập (numeric-input, input-number, expression, text-input) ---------- */
  const inputKind = (hint) => ({
    supported: true,
    format: '{"values":["<answer for field 0>", ...]}  (one string per data.fields entry; ' + hint + ')',
    extract(c) {
      const fields = textInputs(c).map((el, index) => ({ index, label: H.truncate(fieldLabel(el), 120), placeholder: H.truncate(H.clean(el.getAttribute('placeholder')), 60) }));
      if (!fields.length || fields.length > 12) return { insufficient: 'Không tìm thấy ô nhập hợp lệ trong widget.' };
      return { data: { fields }, refs: [] };
    },
    validate(a, d) {
      const v = a && a.values;
      if (!Array.isArray(v) || v.length !== d.fields.length) return { error: 'values không khớp số ô nhập' };
      const out = v.map(x => (typeof x === 'number' ? String(x) : x));
      if (!out.every(x => typeof x === 'string' && x.trim() && x.length <= 200)) return { error: 'giá trị ô nhập rỗng hoặc quá dài' };
      return { value: { values: out.map(x => x.trim()) } };
    },
    describe: (v, d) => ({ lines: v.values.map((x, i) => (d.fields[i].label ? d.fields[i].label + ': ' : 'Ô ' + (i + 1) + ': ') + x), marks: [] })
  });

  /* ---------- Bảng / ma trận (ô nhập nằm trong ô bảng) ---------- */
  const grid = (needRows) => ({
    supported: true,
    format: '{"cells":[{"row":<r>,"col":<c>,"value":"<text>"}]}  (0-based; only cells that are "[ô nhập]" in data.rows)',
    extract(c) {
      const trs = [...c.querySelectorAll('tr')].filter(vis).slice(0, LIMITS.rows);
      if (!trs.length) return { insufficient: needRows ? 'Không xác định được hàng/cột của ma trận từ DOM.' : 'Không tìm thấy bảng.' };
      const rows = trs.map(tr => [...tr.children].filter(x => /^(td|th)$/i.test(x.tagName)).slice(0, LIMITS.cols).map(td => H.truncate(E.textOf(td), 80)));
      if (!rows.some(r => r.some(t => t.includes('[ô nhập]')))) return { insufficient: 'Bảng không có ô nào cần điền.' };
      return { data: { rows }, refs: [] };
    },
    validate(a, d) {
      const cells = a && a.cells;
      if (!Array.isArray(cells) || !cells.length) return { error: 'cells trống' };
      const seen = new Set(), out = [];
      for (const x of cells) {
        const row = x && x.row, col = x && x.col, val = x && (typeof x.value === 'number' ? String(x.value) : x.value);
        if (!isIdx(row, d.rows.length) || !isIdx(col, d.rows[row].length)) return { error: 'ô ngoài phạm vi bảng' };
        if (!d.rows[row][col].includes('[ô nhập]')) return { error: 'AI điền vào ô không phải ô nhập' };
        if (typeof val !== 'string' || !val.trim() || val.length > 100 || seen.has(row + ',' + col)) return { error: 'giá trị ô không hợp lệ hoặc trùng' };
        seen.add(row + ',' + col); out.push({ row, col, value: val.trim() });
      }
      const need = d.rows.reduce((n, r) => n + r.filter(t => t.includes('[ô nhập]')).length, 0);
      if (out.length !== need) return { error: 'AI không điền đủ các ô nhập' };
      return { value: { cells: out } };
    },
    describe: (v) => ({ lines: v.cells.map(x => 'Hàng ' + (x.row + 1) + ', cột ' + (x.col + 1) + ': ' + x.value), marks: [], table: v.cells })
  });

  /* ---------- Widget dạng danh sách (CHƯA kiểm thử trên DOM thật) ---------- */
  const listItems = (c) => itemsFrom(c, '[draggable="true"],[role=listitem],li');
  const orderer = (name) => ({
    supported: true, experimental: true,
    format: '{"order":[<item index>, ...]}  (every item index exactly once, in the correct order)',
    extract(c) {
      const items = listItems(c).slice(0, LIMITS.items);
      if (items.length < 2 || items.some(x => blind(x.text))) return { insufficient: 'Không đọc được các phần tử cần sắp xếp.' };
      return { data: { items: items.map((x, index) => ({ index, text: x.text })) }, refs: items.map(x => x.el) };
    },
    validate(a, d) {
      const o = a && a.order, n = d.items.length;
      if (!Array.isArray(o) || o.length !== n || !o.every(i => isIdx(i, n)) || new Set(o).size !== n) return { error: 'order không phải hoán vị hợp lệ' };
      return { value: { order: o } };
    },
    describe: (v, d) => ({ lines: v.order.map((i, k) => (k + 1) + '. ' + d.items[i].text), marks: [] })
  });
  const categorizer = {
    supported: true, experimental: true,
    format: '{"assignments":[{"item":<item index>,"category":<category index>}]}  (every item exactly once)',
    extract(c) {
      const rows = [...c.querySelectorAll('tr')].filter(vis);
      const cell = tr => tr.querySelector('th,td');
      const cats = rows.length ? [...rows[0].children].map(x => E.textOf(x)).filter(Boolean).slice(0, 10) : [];
      const items = rows.slice(1).map(tr => (cell(tr) ? E.textOf(cell(tr)) : '')).filter(Boolean).slice(0, LIMITS.items);
      if (cats.length < 2 || items.length < 1 || [...cats, ...items].some(blind)) return { insufficient: 'Không xác định được nhóm và phần tử cần phân loại.' };
      return { data: { categories: cats.map((text, index) => ({ index, text })), items: items.map((text, index) => ({ index, text })) }, refs: [] };
    },
    validate(a, d) {
      const x = a && a.assignments;
      if (!Array.isArray(x) || x.length !== d.items.length) return { error: 'assignments không đủ phần tử' };
      const seen = new Set();
      for (const e of x) { if (!e || !isIdx(e.item, d.items.length) || !isIdx(e.category, d.categories.length) || seen.has(e.item)) return { error: 'assignment không hợp lệ' }; seen.add(e.item); }
      return { value: { assignments: x.map(e => ({ item: e.item, category: e.category })) } };
    },
    describe: (v, d) => ({ lines: v.assignments.map(e => d.items[e.item].text + ' → ' + d.categories[e.category].text), marks: [] })
  };
  const matcher = {
    supported: true, experimental: true,
    format: '{"pairs":[{"left":<left index>,"right":<right index>}]}  (each left once, each right once)',
    extract(c) {
      const lists = [...c.querySelectorAll('ul,ol,[role=list]')].filter(vis);
      if (lists.length < 2) return { insufficient: 'Không xác định được hai cột của bài ghép cặp.' };
      const mk = l => itemsFrom(l, 'li,[role=listitem],[draggable="true"]').slice(0, LIMITS.items).map((x, index) => ({ index, text: x.text }));
      const left = mk(lists[0]), right = mk(lists[1]);
      if (left.length < 1 || left.length !== right.length) return { insufficient: 'Hai cột ghép cặp không cân xứng hoặc không đọc được.' };
      return { data: { left, right }, refs: [] };
    },
    validate(a, d) {
      const p = a && a.pairs, n = d.left.length;
      if (!Array.isArray(p) || p.length !== n) return { error: 'pairs không đủ' };
      const L = new Set(), R = new Set();
      for (const e of p) { if (!e || !isIdx(e.left, n) || !isIdx(e.right, n) || L.has(e.left) || R.has(e.right)) return { error: 'pair không hợp lệ' }; L.add(e.left); R.add(e.right); }
      return { value: { pairs: p.map(e => ({ left: e.left, right: e.right })) } };
    },
    describe: (v, d) => ({ lines: v.pairs.map(e => d.left[e.left].text + ' ↔ ' + d.right[e.right].text), marks: [] })
  };

  /* ---------- Widget hình/đồ thị: không đọc chính xác được từ DOM ---------- */
  const NO_GRAPH = 'Widget đồ thị/hình ảnh lưu trạng thái trong SVG/canvas, DOM không cung cấp đủ dữ liệu để giải chính xác.';

  const REGISTRY = {
    'radio': radio,
    'dropdown': dropdown,
    'numeric-input': inputKind('a number: integer, decimal or fraction like 3/4'),
    'input-number': inputKind('a number'),
    'expression': inputKind('a math expression in plain text, e.g. 2x+3 or (x-1)^2'),
    'text-input': inputKind('plain text or number'),
    'table': grid(false),
    'matrix': grid(true),
    'orderer': orderer('orderer'),
    'sorter': orderer('sorter'),
    'categorizer': categorizer,
    'matcher': matcher,
    'grapher': unsupported(NO_GRAPH),
    'interactive-graph': unsupported(NO_GRAPH),
    'plotter': unsupported(NO_GRAPH),
    'number-line': unsupported(NO_GRAPH),
    'label-image': unsupported('Widget gắn nhãn ảnh cần vị trí điểm trên ảnh, DOM không cung cấp.')
  };

  /* ---------- Bộ nhận diện ---------- */
  // Perseus gắn class "perseus-widget-<tên>" lên vùng chứa widget (cần xác nhận lại trên DOM thật khi Khan đổi giao diện).
  function detect(rootEl) {
    const found = [];
    for (const el of rootEl.querySelectorAll('[class*="perseus-widget-"]')) {
      for (const cls of el.classList) {
        const m = /^perseus-widget-(.+)$/.exec(cls);
        if (m && REGISTRY[m[1]] && m[1] !== 'text-input' && vis(el)) { found.push({ type: m[1], el }); break; }
      }
    }
    // loại phần tử lồng nhau cùng loại
    const top = found.filter(a => !found.some(b => b !== a && b.type === a.type && b.el.contains(a.el)));
    if (top.length) return { widgets: top, fallback: false };
    // Dự phòng theo cấu trúc khi không có class widget
    const fb = [];
    if (rootEl.querySelector('input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]')) fb.push({ type: 'radio', el: rootEl });
    else if (rootEl.querySelector('select')) fb.push({ type: 'dropdown', el: rootEl });
    else if (textInputs(rootEl).length) fb.push({ type: 'text-input', el: rootEl });
    return { widgets: fb, fallback: true };
  }

  K.widgets = { REGISTRY, detect, LIMITS };
  if (typeof module === 'object' && module.exports) module.exports = K.widgets;
})(globalThis);
