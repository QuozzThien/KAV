/* Tiện ích dùng chung. Các file trong extension chia sẻ không gian tên globalThis.KPA
 * (content script cùng extension dùng chung một "isolated world"); cũng chạy được trong Node để test. */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const clean = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  const truncate = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

  // Hiển thị thật sự: không display:none / visibility:hidden / hidden ở bất kỳ tổ tiên nào; có kích thước (nếu bật layout)
  function isVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    const view = el.ownerDocument.defaultView;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.hidden) return false;
      if (view.getComputedStyle(n).display === 'none') return false;
    }
    if (view.getComputedStyle(el).visibility === 'hidden') return false;
    if ((K.config || {}).useLayout !== false) {
      const r = el.getBoundingClientRect();
      if (!r.width && !r.height) return false;
    }
    return true;
  }
  const hashString = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };

  K.helpers = { clean, truncate, isVisible, hashString };
  if (typeof module === 'object' && module.exports) module.exports = K.helpers;
})(globalThis);
