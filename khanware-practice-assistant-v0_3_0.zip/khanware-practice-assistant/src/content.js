/* Giao diện + điều phối. Chỉ đọc trang và hiển thị gợi ý; không chọn, không nhập, không nộp bài. */
(() => {
  if (window.__KPA_LOADED__) return;
  window.__KPA_LOADED__ = true;
  const K = globalThis.KPA, T = K.transport;
  const st = { open: false, collapsed: false, theme: "auto", seq: 0, reqId: null, busy: false, fp: "", refs: {}, last: null, observer: null, timer: null };

  /* ---------- Dựng giao diện (chỉ DOM API, không innerHTML) ---------- */
  const mk = (tag, attrs = {}, text) => { const e = document.createElement(tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); if (text != null) e.textContent = text; return e; };
  const host = mk("div", { id: "kpa-host" });
  const launch = mk("button", { id: "kpa-launch", type: "button", title: "Mở trợ lý luyện tập" }, "AI");
  const panel = mk("section", { id: "kpa-panel", "aria-label": "Khanware Practice Assistant" }); panel.hidden = true;
  const header = mk("header");
  const title = mk("strong", {}, "Practice Assistant");
  const bTheme = mk("button", { type: "button", "aria-label": "Đổi giao diện sáng/tối", title: "Sáng/Tối" }, "◐");
  const bMin = mk("button", { type: "button", "aria-label": "Thu nhỏ", title: "Thu nhỏ/Mở rộng" }, "–");
  const bClose = mk("button", { id: "kpa-close", type: "button", "aria-label": "Đóng" }, "×");
  header.append(title, bTheme, bMin, bClose);
  const body = mk("div", { class: "kpa-body" });
  body.append(mk("p", { class: "kpa-note" }, "Chỉ đọc nội dung đang hiển thị và gợi ý. Không tự chọn, điền hoặc nộp bài."));
  const bAnalyze = mk("button", { id: "kpa-analyze", type: "button" }, "Phân tích câu hỏi hiện tại");
  const bCopy = mk("button", { id: "kpa-copy", type: "button" }, "Sao chép kết quả"); bCopy.hidden = true;
  const bOpts = mk("button", { id: "kpa-settings", type: "button", class: "kpa-link" }, "Cài đặt API key / model");
  const status = mk("div", { id: "kpa-status", role: "status" });
  const result = mk("div", { id: "kpa-result" });
  body.append(bAnalyze, bCopy, status, result, bOpts);
  panel.append(header, body); host.append(launch, panel);
  document.documentElement.appendChild(host);

  const setStatus = (msg, kind) => { status.textContent = msg; status.dataset.kind = kind || ""; };

  /* ---------- Tùy chọn giao diện (chrome.storage.sync: chỉ lưu theme/thu nhỏ, KHÔNG lưu key) ---------- */
  function applyTheme() {
    host.dataset.theme = st.theme === "auto" ? ((window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light") : st.theme;
    panel.classList.toggle("kpa-collapsed", st.collapsed);
    bMin.textContent = st.collapsed ? "+" : "–";
  }
  T.getPrefs(v => { st.theme = v.kpaTheme || "auto"; st.collapsed = !!v.kpaCollapsed; applyTheme(); });
  const savePrefs = () => T.setPrefs({ theme: st.theme, collapsed: st.collapsed });

  /* ---------- Hủy / làm sạch ---------- */
  function cancelPending() {
    st.seq++;
    if (st.reqId) { T.abort(st.reqId); st.reqId = null; }
    st.busy = false; bAnalyze.disabled = false;
  }
  function clearResult() { result.replaceChildren(); bCopy.hidden = true; st.last = null; st.refs = {}; K.renderer.clearMarks(); }

  /* ---------- Phân tích ---------- */
  async function analyze() {
    cancelPending(); clearResult();
    const my = st.seq; st.busy = true; bAnalyze.disabled = true;
    try {
      setStatus("Đang đọc câu hỏi…", "busy");
      const read = await K.reader.waitAndRead({ timeoutMs: 5000, settleMs: 500 });
      if (my !== st.seq) return;
      const ex = read.exercise; st.fp = ex.fingerprint;
      if (ex.status !== "ok") { // không đoán: báo rõ lý do
        setStatus((ex.status === "unsupported" ? "Chưa hỗ trợ: " : "Chưa đủ dữ liệu: ") + ex.reason, "warn");
        return;
      }
      const prompt = K.promptBuilder.build(ex);
      if (prompt.error) { setStatus(prompt.error, "warn"); return; }
      st.reqId = "kpa-" + Date.now() + "-" + my;
      setStatus("Đang hỏi AI… (có thể hủy bằng cách chuyển câu hỏi)", "busy");
      const res = await T.solve(st.reqId, prompt.system, prompt.user);
      if (my !== st.seq) return; // đã đổi câu / hủy
      st.reqId = null;
      if (!res?.ok) throw new Error(res?.error || "Không nhận được phản hồi từ tiện ích.");
      let parsed; try { parsed = K.responseParser.extractJson(res.result); } catch (e) { throw new Error(e.message + " Hãy thử lại hoặc đổi model."); }
      const v = K.responseParser.validate(parsed, ex);
      if (!v.ok) throw new Error("Phản hồi AI không khớp dữ liệu câu hỏi (" + v.errors.join("; ") + "). Bấm phân tích lại.");
      // chống race: câu hỏi phải còn nguyên như lúc gửi
      if (K.reader.read().exercise.fingerprint !== ex.fingerprint) { setStatus("Câu hỏi đã thay đổi trong lúc chờ AI. Bấm phân tích lại.", "warn"); return; }
      st.last = v; st.refs = read.refs;
      result.append(K.renderer.buildResultNode(document, v));
      K.renderer.applyMarks(read.refs, v);
      bCopy.hidden = false; bAnalyze.textContent = "Phân tích lại";
      setStatus("Đã có gợi ý. Bạn tự quyết định thao tác trên bài tập.", "ok");
    } catch (e) {
      if (my === st.seq) setStatus(e.message, "error");
    } finally { if (my === st.seq) { st.busy = false; bAnalyze.disabled = false; st.reqId = null; } }
  }

  /* ---------- Theo dõi đổi câu hỏi (chỉ khi panel mở; debounce; ngắt khi đóng) ---------- */
  function onMutations(list) {
    if (list.every(m => host.contains(m.target))) return;
    clearTimeout(st.timer);
    st.timer = setTimeout(() => {
      if (!st.open || !st.fp) return;
      let fp; try { fp = K.reader.read().exercise.fingerprint; } catch (_) { return; }
      if (fp !== st.fp) { cancelPending(); clearResult(); st.fp = ""; bAnalyze.textContent = "Phân tích câu hỏi hiện tại"; setStatus("Câu hỏi đã thay đổi. Bấm phân tích để nhận gợi ý mới.", ""); }
    }, 500);
  }
  function startObserver() { if (st.observer) return; st.observer = new MutationObserver(onMutations); st.observer.observe(document.body, { childList: true, subtree: true }); }
  function stopObserver() { st.observer?.disconnect(); st.observer = null; clearTimeout(st.timer); }

  /* ---------- Sự kiện (đăng ký đúng một lần) ---------- */
  launch.addEventListener("click", () => { st.open = true; panel.hidden = false; startObserver(); });
  bClose.addEventListener("click", () => { st.open = false; panel.hidden = true; stopObserver(); cancelPending(); K.renderer.clearMarks(); });
  bMin.addEventListener("click", () => { st.collapsed = !st.collapsed; applyTheme(); savePrefs(); });
  bTheme.addEventListener("click", () => { st.theme = host.dataset.theme === "dark" ? "light" : "dark"; applyTheme(); savePrefs(); });
  bAnalyze.addEventListener("click", analyze);
  bCopy.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(K.renderer.textSummary(st.last)); setStatus("Đã sao chép kết quả.", "ok"); }
    catch (_) { setStatus("Không sao chép được (trình duyệt chặn clipboard).", "error"); }
  });
  bOpts.addEventListener("click", () => T.openSettings({ mk, body, setStatus }));
  window.__KPA_OPEN__ = () => { st.open = true; panel.hidden = false; startObserver(); };
  addEventListener("pagehide", () => { stopObserver(); cancelPending(); });
})();
