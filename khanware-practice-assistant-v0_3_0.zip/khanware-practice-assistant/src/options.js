const $ = s => document.querySelector(s);
const keyInput = $("#key"), modelInput = $("#model"), status = $("#status");
const say = (t, bad) => { status.textContent = t; status.style.color = bad ? "#b91c1c" : ""; };

chrome.storage.local.get(["apiKey", "model"]).then(({ apiKey, model }) => {
  keyInput.value = apiKey || "";
  modelInput.value = model || "openrouter/free";
});

async function save() {
  const apiKey = keyInput.value.trim();
  const model = modelInput.value.trim() || "openrouter/free";
  if (apiKey && !/^sk-or-[\w-]{10,}$/.test(apiKey)) { say("Key có định dạng không quen thuộc (thường bắt đầu bằng sk-or-). Hãy kiểm tra lại.", true); return false; }
  if (!/^[\w.:\-\/]{1,100}$/.test(model)) { say("Tên model không hợp lệ.", true); return false; }
  await chrome.storage.local.set({ apiKey, model });
  say("Đã lưu cài đặt trên trình duyệt này."); return true;
}
$("#save").addEventListener("click", save);
$("#toggle").addEventListener("click", () => { const show = keyInput.type === "password"; keyInput.type = show ? "text" : "password"; $("#toggle").textContent = show ? "Ẩn" : "Hiện"; });
$("#clear").addEventListener("click", async () => { await chrome.storage.local.remove("apiKey"); keyInput.value = ""; say("Đã xóa API key."); });
$("#test").addEventListener("click", async () => {
  if (!(await save())) return;
  say("Đang kiểm tra…");
  const r = await chrome.runtime.sendMessage({ type: "KPA_TEST" }).catch(e => ({ ok: false, error: e.message }));
  say(r?.ok ? "Kết nối OpenRouter thành công." : (r?.error || "Thất bại."), !r?.ok);
});
