/* Hiển thị gợi ý. Chỉ dùng textContent/createElement (không innerHTML với nội dung không tin cậy).
 * Chỉ thêm/bỏ một class viền (kpa-mark) trên phần tử phương án; không click, không đổi nội dung, không nhập liệu. */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const TYPE_VI = { radio: 'Trắc nghiệm', dropdown: 'Danh sách chọn', 'numeric-input': 'Điền số', 'input-number': 'Điền số', expression: 'Biểu thức', 'text-input': 'Ô nhập', table: 'Bảng', matrix: 'Ma trận', orderer: 'Sắp xếp', sorter: 'Sắp xếp', categorizer: 'Phân loại', matcher: 'Ghép cặp' };
  let marked = [];

  const el = (doc, tag, cls, text) => { const e = doc.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  function buildResultNode(doc, v) {
    const box = el(doc, 'div', 'kpa-results');
    for (const r of v.results) {
      const sec = el(doc, 'section', 'kpa-card');
      sec.append(el(doc, 'strong', '', (TYPE_VI[r.type] || r.type) + ' (' + r.widgetId + ')' + (r.experimental ? ' – thử nghiệm' : '')));
      if (r.insufficient) sec.append(el(doc, 'div', 'kpa-value kpa-warn', 'AI cho biết chưa đủ dữ liệu để trả lời widget này.'));
      else if (r.table) {
        const t = el(doc, 'table', 'kpa-table');
        for (const c of r.table) { const tr = el(doc, 'tr'); tr.append(el(doc, 'td', '', 'Hàng ' + (c.row + 1) + ', cột ' + (c.col + 1)), el(doc, 'td', 'kpa-math', c.value)); t.append(tr); }
        sec.append(t);
      } else for (const line of r.lines) sec.append(el(doc, 'div', 'kpa-value' + (r.type === 'expression' ? ' kpa-math' : ''), '✓ ' + line));
      box.append(sec);
    }
    if (v.explanation) { const s = el(doc, 'section', 'kpa-card'); s.append(el(doc, 'strong', '', 'Giải thích'), el(doc, 'div', 'kpa-value', v.explanation)); box.append(s); }
    if (v.confidence != null) box.append(el(doc, 'div', 'kpa-conf', 'Độ tin cậy (AI tự đánh giá): ' + Math.round(v.confidence * 100) + '%'));
    if (v.needsMoreInfo) box.append(el(doc, 'div', 'kpa-warn', 'Dữ liệu có thể chưa đủ. Hãy tự kiểm tra trước khi dùng gợi ý.'));
    return box;
  }

  function textSummary(v) {
    const parts = [];
    for (const r of v.results) parts.push((TYPE_VI[r.type] || r.type) + ' (' + r.widgetId + '):\n' + (r.table ? r.table.map(c => 'Hàng ' + (c.row + 1) + ', cột ' + (c.col + 1) + ': ' + c.value) : r.lines).join('\n'));
    if (v.explanation) parts.push('Giải thích: ' + v.explanation);
    return parts.join('\n\n');
  }

  function clearMarks() { for (const e of marked) e.classList.remove('kpa-mark'); marked = []; }
  function applyMarks(refs, v) {
    clearMarks();
    for (const r of v.results) for (const i of r.marks || []) { const t = (refs[r.widgetId] || [])[i]; if (t && t.isConnected) { t.classList.add('kpa-mark'); marked.push(t); } }
    return marked.length;
  }

  K.renderer = { buildResultNode, textSummary, applyMarks, clearMarks };
  if (typeof module === 'object' && module.exports) module.exports = K.renderer;
})(globalThis);
