/* Trích văn bản hiển thị từ DOM. Không đọc giá trị người dùng đã nhập hay trạng thái đã chọn. */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const H = K.helpers;
  const SKIP = new Set(['script', 'style', 'noscript', 'template']);

  // opts.replace: Map<Element,string> thay thế cả khối (dùng để thay widget bằng nhãn [WIDGET w1: radio])
  function nodeText(node, opts) {
    opts = opts || {};
    if (node.nodeType === 3) return node.nodeValue;
    if (node.nodeType !== 1) return '';
    const el = node, tag = el.tagName.toLowerCase();
    if (SKIP.has(tag)) return '';
    if (opts.replace && opts.replace.has(el)) return ' ' + opts.replace.get(el) + ' ';
    // KaTeX: lấy mã TeX gốc, tránh lặp chữ giữa lớp MathML và lớp HTML
    if (el.classList.contains('katex')) {
      const ann = el.querySelector('annotation[encoding="application/x-tex"]');
      const t = H.clean(ann ? ann.textContent : (el.querySelector('.katex-mathml') || el).textContent);
      return t ? ' $' + t + '$ ' : '';
    }
    if (el.getAttribute('aria-hidden') === 'true') return '';
    if (!H.isVisible(el)) return '';
    if (tag === 'img') { const a = H.clean(el.getAttribute('alt')); return a ? ' [ảnh: ' + a + '] ' : ' [ảnh không có mô tả] '; }
    if (tag === 'svg') {
      const t = H.clean(el.getAttribute('aria-label') || (el.querySelector('title') || {}).textContent);
      return t ? ' [hình vẽ: ' + t + '] ' : ' [hình vẽ] ';
    }
    if (tag === 'canvas') return ' [hình vẽ canvas] ';
    if (tag === 'select') return ' [danh sách chọn] ';
    if (tag === 'textarea') return ' [ô nhập] ';
    if (tag === 'input') {
      const t = (el.getAttribute('type') || 'text').toLowerCase();
      return ['radio', 'checkbox', 'hidden', 'submit', 'button'].includes(t) ? '' : ' [ô nhập] ';
    }
    let out = '';
    for (const c of el.childNodes) out += nodeText(c, opts) + ' ';
    return out;
  }
  const textOf = (el, opts) => H.clean(nodeText(el, opts));

  K.extractor = { nodeText, textOf };
  if (typeof module === 'object' && module.exports) module.exports = K.extractor;
})(globalThis);
