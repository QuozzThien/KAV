/* Đọc câu hỏi đang hiển thị -> JSON chuẩn hóa. Không đọc đáp án ẩn, giá trị đã nhập hay trạng thái đã chọn. */
(function (root) {
  const K = root.KPA || (root.KPA = {});
  const H = K.helpers, E = K.extractor, W = K.widgets;
  const RENDERER_SEL = '.framework-perseus,.perseus-renderer';
  const FALLBACK_ROOTS = ['[data-testid*="exercise"]', '[data-testid*="question"]', '.framework-perseus', '.perseus-renderer', 'main', '[role=main]'];

  function lca(els) {
    const path = n => { const p = []; for (; n; n = n.parentElement) p.unshift(n); return p; };
    let common = path(els[0]);
    for (const el of els.slice(1)) { const p = path(el); let i = 0; while (i < common.length && common[i] === p[i]) i++; common = common.slice(0, i); }
    return common[common.length - 1];
  }
  // Vùng câu hỏi = bộ render Perseus ngoài cùng chứa tất cả widget (tránh thanh điều hướng/giao diện phụ)
  function widgetRoot(widgets) {
    const common = lca(widgets.map(w => w.el));
    let best = null;
    for (let n = common; n && n.tagName !== 'BODY'; n = n.parentElement) if (n.matches(RENDERER_SEL)) best = n;
    return best || common.parentElement || common;
  }
  function fallbackRoot(doc) {
    for (const s of FALLBACK_ROOTS) { const el = [...doc.querySelectorAll(s)].find(H.isVisible); if (el) return el; }
    return doc.body;
  }

  function read(doc) {
    doc = doc || document;
    let det = W.detect(doc.body), rootEl;
    if (!det.fallback) rootEl = widgetRoot(det.widgets);
    else { rootEl = fallbackRoot(doc); det = W.detect(rootEl); }

    const replace = new Map(), refs = {}, widgets = [];
    det.widgets.forEach((w, i) => { w.id = 'w' + (i + 1); if (!det.fallback) replace.set(w.el, '[WIDGET ' + w.id + ': ' + w.type + ']'); });
    const questionText = H.truncate(E.textOf(rootEl, { replace }), 6000);

    for (const w of det.widgets) {
      const spec = W.REGISTRY[w.type];
      if (spec.supported === false) { widgets.push({ id: w.id, type: w.type, status: 'unsupported', reason: spec.reason }); continue; }
      const ex = spec.extract(w.el);
      if (ex.insufficient) { widgets.push({ id: w.id, type: w.type, status: 'insufficient_data', reason: ex.insufficient }); continue; }
      widgets.push({ id: w.id, type: w.type, status: 'ok', experimental: !!spec.experimental, data: ex.data });
      refs[w.id] = ex.refs || [];
    }

    let status = 'ok', reason = '';
    const bad = widgets.filter(w => w.status !== 'ok');
    if (!widgets.length) { status = 'insufficient_data'; reason = 'Không nhận diện được widget nào trong câu hỏi đang hiển thị.'; }
    else if (bad.some(w => w.status === 'unsupported')) { status = 'unsupported'; }
    else if (bad.length) { status = 'insufficient_data'; }
    if (bad.length) reason = bad.map(w => w.id + ' (' + w.type + '): ' + w.reason).join('\n');
    if (status === 'ok' && questionText.replace(/\[WIDGET [^\]]*\]/g, '').trim().length < 3) { status = 'insufficient_data'; reason = 'Không đọc được nội dung đề bài.'; }

    const exercise = { status, reason, questionText, widgets };
    exercise.fingerprint = H.hashString((doc.location ? doc.location.pathname : '') + '|' + questionText + '|' + JSON.stringify(widgets));
    return { exercise, refs, rootEl };
  }

  // Chờ widget render xong: kết quả ổn định trong settleMs (tối đa timeoutMs)
  async function waitAndRead(opts) {
    opts = opts || {};
    const doc = opts.doc || document, timeout = opts.timeoutMs || 5000, settle = opts.settleMs || 500, step = opts.stepMs || 150;
    const sleep = opts.sleep || (ms => new Promise(r => setTimeout(r, ms)));
    const t0 = Date.now(); let last = read(doc), stableSince = Date.now();
    while (Date.now() - t0 < timeout) {
      if (opts.signal && opts.signal.aborted) break;
      await sleep(step);
      const cur = read(doc);
      if (cur.exercise.fingerprint !== last.exercise.fingerprint) { last = cur; stableSince = Date.now(); }
      else if (Date.now() - stableSince >= settle && last.exercise.widgets.length) break;
    }
    return last;
  }

  K.reader = { read, waitAndRead };
  if (typeof module === 'object' && module.exports) module.exports = K.reader;
})(globalThis);
