/* Service worker: chỉ làm cầu nối tới OpenRouter. API key chỉ được đọc ở đây (content script không đọc được). */
const DEFAULT_MODEL = "openrouter/free";
const ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";
const TIMEOUT_MS = 45000, MAX_RETRIES = 2, MAX_TOKENS = 900;
const MAX_SYSTEM = 4000, MAX_USER = 14000;
const KHAN_HOST = /^https:\/\/([^/]+\.)?khanacademy\.org\//;
const inflight = new Map(); // requestId -> AbortController

// Chặn content script (chạy trong trang web) đọc chrome.storage.local
function lockStorage() { try { chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }); } catch (_) {} }
lockStorage();
chrome.runtime.onInstalled.addListener(lockStorage);

class KpaError extends Error { constructor(code, message, fatal) { super(message); this.code = code; this.fatal = !!fatal; } }
const sleep = (ms, signal) => new Promise((res, rej) => {
  const t = setTimeout(res, ms);
  signal?.addEventListener("abort", () => { clearTimeout(t); rej(new KpaError("aborted", "Đã hủy yêu cầu.", true)); }, { once: true });
});

function statusError(status, detail) {
  const d = String(detail || "").slice(0, 200);
  switch (status) {
    case 400: return new KpaError("bad_request", `Yêu cầu bị từ chối (400). Model có thể không hỗ trợ định dạng yêu cầu: ${d}`, true);
    case 401: return new KpaError("unauthorized", "API key không đúng hoặc đã bị thu hồi (401). Kiểm tra lại trong phần cài đặt.", true);
    case 403: return new KpaError("forbidden", `Key không có quyền dùng model này hoặc nội dung bị chặn (403): ${d}`, true);
    case 429: return new KpaError("rate_limited", "Đã vượt giới hạn tốc độ/hạn mức (429). Hãy đợi một lúc hoặc đổi model.");
    default:
      if (status >= 500) return new KpaError("server_error", `Máy chủ OpenRouter đang lỗi (${status}). ${d}`);
      return new KpaError("http_error", `Lỗi HTTP ${status}: ${d}`, true);
  }
}

async function callModel({ id, system, user, maxTokens }) {
  const { apiKey, model } = await chrome.storage.local.get(["apiKey", "model"]);
  if (!apiKey) throw new KpaError("no_key", "Chưa cấu hình OpenRouter API key. Mở phần cài đặt tiện ích.", true);
  const ctrl = new AbortController();
  if (id) inflight.set(id, ctrl);
  let jsonMode = true, lastErr;
  try {
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      if (ctrl.signal.aborted) throw new KpaError("aborted", "Đã hủy yêu cầu.", true);
      const attemptCtrl = new AbortController();
      let timedOut = false;
      const onAbort = () => attemptCtrl.abort();
      ctrl.signal.addEventListener("abort", onAbort, { once: true });
      const timer = setTimeout(() => { timedOut = true; attemptCtrl.abort(); }, TIMEOUT_MS);
      let retryAfter = 0;
      try {
        const body = { model: model || DEFAULT_MODEL, temperature: 0.1, max_tokens: maxTokens || MAX_TOKENS,
          messages: [{ role: "system", content: system }, { role: "user", content: user }] };
        if (jsonMode) body.response_format = { type: "json_object" };
        const res = await fetch(ENDPOINT, {
          method: "POST", signal: attemptCtrl.signal,
          headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json", "HTTP-Referer": "https://www.khanacademy.org/", "X-Title": "Khanware Practice Assistant" },
          body: JSON.stringify(body)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data?.error) {
          const status = res.ok ? Number(data.error.code) || 500 : res.status;
          const detail = data?.error?.message || "";
          if (status === 400 && jsonMode && /response_format|json/i.test(detail)) { jsonMode = false; continue; } // model không hỗ trợ JSON mode
          retryAfter = Math.min(Number(res.headers.get("retry-after")) * 1000 || 0, 5000);
          throw statusError(status, detail);
        }
        const content = data?.choices?.[0]?.message?.content;
        if (!content) throw new KpaError("empty", "AI không trả về nội dung.");
        return content;
      } catch (e) {
        if (ctrl.signal.aborted) throw new KpaError("aborted", "Đã hủy yêu cầu.", true);
        if (e instanceof KpaError) { if (e.fatal) throw e; lastErr = e; }
        else lastErr = timedOut ? new KpaError("timeout", "Hết thời gian chờ AI (45 giây).") : new KpaError("network", "Lỗi mạng khi gọi OpenRouter.");
      } finally { clearTimeout(timer); ctrl.signal.removeEventListener("abort", onAbort); }
      if (attempt < MAX_RETRIES) await sleep(retryAfter || 800 * 2 ** attempt, ctrl.signal);
    }
    throw lastErr;
  } finally { if (id) inflight.delete(id); }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !msg) return false;
  const fromKhan = KHAN_HOST.test(sender.tab?.url || "");
  const fromOptions = (sender.url || "").startsWith(chrome.runtime.getURL(""));

  if (msg.type === "KPA_OPEN_OPTIONS" && fromKhan) { chrome.runtime.openOptionsPage(); sendResponse({ ok: true }); return false; }
  if (msg.type === "KPA_ABORT" && fromKhan) { inflight.get(String(msg.id))?.abort(); sendResponse({ ok: true }); return false; }

  if ((msg.type === "KPA_SOLVE" && fromKhan) || (msg.type === "KPA_TEST" && fromOptions)) {
    const test = msg.type === "KPA_TEST";
    const system = test ? 'Reply with exactly this JSON: {"ok":true}' : String(msg.system || "");
    const user = test ? "ping" : String(msg.user || "");
    if (!system || !user || system.length > MAX_SYSTEM || user.length > MAX_USER) {
      sendResponse({ ok: false, code: "bad_input", error: "Dữ liệu câu hỏi trống hoặc quá dài." }); return false;
    }
    callModel({ id: test ? null : String(msg.id || ""), system, user, maxTokens: test ? 20 : MAX_TOKENS })
      .then(result => sendResponse({ ok: true, result }))
      .catch(e => sendResponse({ ok: false, code: e.code || "error", error: e.message || "Lỗi không xác định." }));
    return true;
  }
  return false;
});
