// Dựng môi trường jsdom + nạp các module theo đúng thứ tự trong manifest. Fixture là HTML TỰ VIẾT (không phải DOM thật của Khan Academy).
const { JSDOM } = require('jsdom');
const path = require('path');
module.exports = function load(html) {
  const dom = new JSDOM('<!doctype html><body>' + html + '</body>', { url: 'https://www.khanacademy.org/math/x/e/1' });
  globalThis.document = dom.window.document;
  globalThis.KPA = { config: { useLayout: false } };
  for (const k of Object.keys(require.cache)) if (k.includes(path.sep + 'src' + path.sep)) delete require.cache[k];
  for (const f of ['shared/helpers', 'reader/contentExtractor', 'widgets/registry', 'reader/questionReader', 'ai/promptBuilder', 'ai/responseParser', 'renderer/suggestionPanel'])
    require(path.join(__dirname, '..', 'src', f + '.js'));
  return { K: globalThis.KPA, doc: dom.window.document };
};
