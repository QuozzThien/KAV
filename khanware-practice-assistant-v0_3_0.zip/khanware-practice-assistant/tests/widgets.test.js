const test = require('node:test'), assert = require('node:assert');
const load = require('./helpers');
const R = (K, t) => K.widgets.REGISTRY[t];

test('radio: validate chấp nhận/loại đúng', () => {
  const { K } = load('');
  const d = { multiple: false, options: [{ index: 0, text: 'a' }, { index: 1, text: 'b' }] };
  assert.ok(R(K, 'radio').validate({ selected: [1] }, d).value);
  for (const bad of [{ selected: [2] }, { selected: [0, 1] }, { selected: [] }, { selected: ['0'] }, {}, null]) assert.ok(R(K, 'radio').validate(bad, d).error, JSON.stringify(bad));
  assert.ok(R(K, 'radio').validate({ selected: [0, 1] }, { ...d, multiple: true }).value);
});
test('dropdown <select> bỏ placeholder', () => {
  const { K } = load('<div class="perseus-renderer"><p>Chọn</p><div class="perseus-widget-dropdown"><select><option value="">Chọn…</option><option>bé hơn</option><option>lớn hơn</option></select></div></div>');
  const w = K.reader.read().exercise.widgets[0];
  assert.deepEqual(w.data.options.map(o => o.text), ['bé hơn', 'lớn hơn']);
  assert.ok(R(K, 'dropdown').validate({ selected: 1 }, w.data).value);
  assert.ok(R(K, 'dropdown').validate({ selected: 5 }, w.data).error);
});
test('dropdown tùy biến đang đóng => insufficient_data', () => {
  const { K } = load('<div class="perseus-renderer"><p>Chọn</p><div class="perseus-widget-dropdown"><button role="combobox" aria-expanded="false">▼</button></div></div>');
  assert.equal(K.reader.read().exercise.widgets[0].status, 'insufficient_data');
});
test('numeric/expression/input-number: nhận diện + validate', () => {
  for (const t of ['numeric-input', 'input-number', 'expression']) {
    const { K } = load(`<div class="perseus-renderer"><p>x?</p><div class="perseus-widget-${t}"><input type="text" aria-label="đáp số"></div></div>`);
    const w = K.reader.read().exercise.widgets[0];
    assert.equal(w.type, t); assert.equal(w.data.fields[0].label, 'đáp số');
    assert.deepEqual(R(K, t).validate({ values: [42] }, w.data).value, { values: ['42'] });
    for (const bad of [{ values: [] }, { values: [''] }, { values: ['1', '2'] }, { values: [{}] }]) assert.ok(R(K, t).validate(bad, w.data).error);
  }
});
test('table: chỉ cho điền vào ô nhập', () => {
  const { K } = load('<div class="perseus-renderer"><p>Hoàn thành bảng</p><div class="perseus-widget-table"><table><tr><td>x</td><td>y</td></tr><tr><td>1</td><td><input type="text"></td></tr></table></div></div>');
  const w = K.reader.read().exercise.widgets[0];
  assert.deepEqual(w.data.rows[1], ['1', '[ô nhập]']);
  assert.ok(R(K, 'table').validate({ cells: [{ row: 1, col: 1, value: '5' }] }, w.data).value);
  assert.ok(R(K, 'table').validate({ cells: [{ row: 0, col: 0, value: '5' }] }, w.data).error);
  assert.ok(R(K, 'table').validate({ cells: [] }, w.data).error);
});
test('matrix không có <tr> => insufficient_data', () => {
  const { K } = load('<div class="perseus-renderer"><p>M</p><div class="perseus-widget-matrix"><div><input type="text"><input type="text"></div></div></div>');
  assert.equal(K.reader.read().exercise.widgets[0].status, 'insufficient_data');
});
test('orderer/sorter: phải là hoán vị', () => {
  const { K } = load('');
  const d = { items: [{ index: 0, text: 'a' }, { index: 1, text: 'b' }, { index: 2, text: 'c' }] };
  for (const t of ['orderer', 'sorter']) {
    assert.ok(R(K, t).validate({ order: [2, 0, 1] }, d).value);
    for (const bad of [{ order: [0, 0, 1] }, { order: [0, 1] }, { order: [0, 1, 3] }]) assert.ok(R(K, t).validate(bad, d).error);
  }
});
test('categorizer & matcher: validate', () => {
  const { K } = load('');
  const cd = { categories: [{ index: 0 }, { index: 1 }], items: [{ index: 0 }, { index: 1 }] };
  assert.ok(R(K, 'categorizer').validate({ assignments: [{ item: 0, category: 1 }, { item: 1, category: 0 }] }, cd).value);
  assert.ok(R(K, 'categorizer').validate({ assignments: [{ item: 0, category: 2 }, { item: 1, category: 0 }] }, cd).error);
  assert.ok(R(K, 'categorizer').validate({ assignments: [{ item: 0, category: 0 }, { item: 0, category: 1 }] }, cd).error);
  const md = { left: [{}, {}], right: [{}, {}] };
  assert.ok(R(K, 'matcher').validate({ pairs: [{ left: 0, right: 1 }, { left: 1, right: 0 }] }, md).value);
  assert.ok(R(K, 'matcher').validate({ pairs: [{ left: 0, right: 1 }, { left: 1, right: 1 }] }, md).error);
});
test('categorizer/orderer/matcher: trích xuất từ HTML tự viết', () => {
  const { K } = load(`<div class="perseus-renderer"><p>P</p>
   <div class="perseus-widget-categorizer"><table><thead><tr><th></th><th>Chẵn</th><th>Lẻ</th></tr></thead><tbody><tr><th>2</th><td></td><td></td></tr><tr><th>3</th><td></td><td></td></tr></tbody></table></div>
   <div class="perseus-widget-orderer"><ul><li>b</li><li>a</li></ul></div>
   <div class="perseus-widget-matcher"><ul><li>x</li><li>y</li></ul><ul><li>1</li><li>2</li></ul></div></div>`);
  const ws = K.reader.read().exercise.widgets;
  assert.deepEqual(ws.map(w => w.status), ['ok', 'ok', 'ok']);
  assert.deepEqual(ws[0].data.categories.map(c => c.text), ['Chẵn', 'Lẻ']);
  assert.deepEqual(ws[0].data.items.map(c => c.text), ['2', '3']);
  assert.ok(ws.every(w => w.experimental));
});
test('5 widget hình => unsupported', () => {
  for (const t of ['grapher', 'interactive-graph', 'plotter', 'number-line', 'label-image']) {
    const { K } = load(`<div class="perseus-renderer"><p>P</p><div class="perseus-widget-${t}"><svg/></div></div>`);
    const ex = K.reader.read().exercise;
    assert.equal(ex.status, 'unsupported', t); assert.equal(ex.widgets[0].type, t);
  }
});
