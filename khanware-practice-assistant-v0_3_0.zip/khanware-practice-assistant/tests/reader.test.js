const test = require('node:test'), assert = require('node:assert');
const load = require('./helpers');

test('KaTeX: lấy TeX, không lặp chữ', () => {
  const { K, doc } = load('<div class="perseus-renderer"><p>Tính <span class="katex"><span class="katex-mathml"><math><semantics><mrow><mn>2</mn></mrow><annotation encoding="application/x-tex">2+3</annotation></semantics></math></span><span class="katex-html" aria-hidden="true">2+3</span></span></p></div>');
  assert.equal(K.extractor.textOf(doc.body), 'Tính $2+3$');
});
test('ẩn: display:none và aria-hidden bị bỏ qua', () => {
  const { K, doc } = load('<div>A<span style="display:none">SECRET</span><span aria-hidden="true">X</span>B</div>');
  assert.equal(K.extractor.textOf(doc.body), 'A B');
});
test('không đọc giá trị đã nhập / trạng thái đã chọn', () => {
  const { K, doc } = load('<div><input type="text" value="my-answer"><input type="radio" checked> Chọn</div>');
  const t = K.extractor.textOf(doc.body);
  assert.ok(!t.includes('my-answer')); assert.ok(t.includes('[ô nhập]'));
});
test('nhận diện vùng câu hỏi, bỏ qua thanh điều hướng', () => {
  const { K } = load(`<nav>MENU Skip Check</nav><div class="framework-perseus"><div class="perseus-renderer"><p>Thủ đô?</p>
    <div class="perseus-widget-radio"><ul><li><input type="radio"><span>Hà Nội</span></li><li><input type="radio"><span>Huế</span></li></ul></div></div></div>`);
  const { exercise } = K.reader.read();
  assert.equal(exercise.status, 'ok');
  assert.ok(!exercise.questionText.includes('MENU'));
  assert.match(exercise.questionText, /Thủ đô\? \[WIDGET w1: radio\]/);
  assert.deepEqual(exercise.widgets[0].data.options.map(o => o.text), ['Hà Nội', 'Huế']);
});
test('phương án chỉ là ảnh không alt => insufficient_data, không đoán', () => {
  const { K } = load('<div class="perseus-renderer"><p>Chọn hình</p><div class="perseus-widget-radio"><ul><li><input type="radio"><img src="a.png"></li><li><input type="radio"><img src="b.png" alt=""></li></ul></div></div>');
  const { exercise } = K.reader.read();
  assert.equal(exercise.status, 'insufficient_data');
  assert.equal(exercise.widgets[0].status, 'insufficient_data');
});
test('widget đồ thị => unsupported, không gọi AI', () => {
  const { K } = load('<div class="perseus-renderer"><p>Vẽ đường thẳng</p><div class="perseus-widget-interactive-graph"><svg></svg></div></div>');
  const { exercise } = K.reader.read();
  assert.equal(exercise.status, 'unsupported');
  assert.ok(K.promptBuilder.build(exercise).error);
});
test('không có widget => insufficient_data', () => {
  const { K } = load('<main><p>Chỉ có chữ</p></main>');
  assert.equal(K.reader.read().exercise.status, 'insufficient_data');
});
test('fingerprint đổi khi đổi câu hỏi, ổn định khi không đổi', () => {
  const { K, doc } = load('<div class="perseus-renderer"><p>Câu 1</p><div class="perseus-widget-numeric-input"><input type="text" aria-label="đáp số"></div></div>');
  const a = K.reader.read().exercise.fingerprint;
  assert.equal(K.reader.read().exercise.fingerprint, a);
  doc.querySelector('p').textContent = 'Câu 2';
  assert.notEqual(K.reader.read().exercise.fingerprint, a);
});
test('waitAndRead chờ widget render muộn', async () => {
  const { K, doc } = load('<div class="perseus-renderer"><p>Đề</p></div>');
  setTimeout(() => { doc.querySelector('.perseus-renderer').insertAdjacentHTML('beforeend', '<div class="perseus-widget-numeric-input"><input type="text"></div>'); }, 120);
  const r = await K.reader.waitAndRead({ timeoutMs: 3000, settleMs: 200, stepMs: 50 });
  assert.equal(r.exercise.widgets.length, 1);
});
