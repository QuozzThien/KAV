// Kiểm thử service worker bằng chrome/fetch GIẢ (mock), chỉ để kiểm tra logic retry/lỗi/hủy, không gọi mạng thật.
const test = require('node:test'), assert = require('node:assert'), vm = require('node:vm'), fs = require('node:fs');
const SRC = fs.readFileSync(__dirname + '/../src/background.js', 'utf8').replace(/^const /gm, 'var ').replace(/^class /m, 'var KpaError = class ');

function boot(fetchImpl, store = { apiKey: 'sk-or-test-key-123456', model: '' }) {
  let listener; const calls = [];
  const ctx = { console, setTimeout, clearTimeout, AbortController, Promise, Error, Number, Math, String, JSON, Map, URL,
    fetch: async (u, o) => { calls.push(JSON.parse(o.body)); return fetchImpl(calls.length, o); },
    chrome: { runtime: { id: 'me', onInstalled: { addListener() {} }, onMessage: { addListener: f => (listener = f) }, getURL: () => 'chrome-extension://me/', openOptionsPage() {} },
      storage: { local: { setAccessLevel() {}, get: async () => store } } } };
  vm.createContext(ctx); vm.runInContext(SRC, ctx);
  const send = (msg, sender = { id: 'me', tab: { url: 'https://www.khanacademy.org/x' } }) => new Promise(res => { const async = listener(msg, sender, res); if (!async) setTimeout(() => res('no-response'), 20); });
  return { send, calls };
}
const resp = (status, body, headers = {}) => ({ ok: status < 400, status, headers: { get: k => headers[k.toLowerCase()] || null }, json: async () => body });
const OK = resp(200, { choices: [{ message: { content: '{"a":1}' } }] });
const solve = (id = 'r1') => ({ type: 'KPA_SOLVE', id, system: 's', user: 'u' });

test('thành công + gửi JSON mode', async () => {
  const b = boot(async () => OK); const r = await b.send(solve());
  assert.deepEqual([r.ok, r.result], [true, '{"a":1}']); assert.deepEqual(b.calls[0].response_format, { type: 'json_object' });
  assert.equal(b.calls[0].model, 'openrouter/free'); assert.ok(b.calls[0].max_tokens <= 900);
});
test('400 do JSON mode => thử lại không có response_format', async () => {
  const b = boot(async n => (n === 1 ? resp(400, { error: { message: 'response_format not supported' } }) : OK));
  const r = await b.send(solve()); assert.equal(r.ok, true); assert.equal(b.calls[1].response_format, undefined);
});
test('401/403 không retry, thông báo rõ', async () => {
  for (const [st, code] of [[401, 'unauthorized'], [403, 'forbidden']]) {
    const b = boot(async () => resp(st, { error: { message: 'x' } })); const r = await b.send(solve());
    assert.equal(r.code, code); assert.equal(b.calls.length, 1);
  }
});
test('429 retry có giới hạn rồi báo lỗi (tối đa 3 lần gọi)', async () => {
  const b = boot(async () => resp(429, { error: { message: 'slow' } }, { 'retry-after': '0' }));
  const r = await b.send(solve()); assert.equal(r.code, 'rate_limited'); assert.equal(b.calls.length, 3);
});
test('500 rồi thành công', async () => {
  const b = boot(async n => (n === 1 ? resp(500, {}) : OK)); const r = await b.send(solve());
  assert.equal(r.ok, true); assert.equal(b.calls.length, 2);
});
test('thiếu key => lỗi no_key, không gọi mạng', async () => {
  const b = boot(async () => OK, {}); const r = await b.send(solve()); assert.equal(r.code, 'no_key'); assert.equal(b.calls.length, 0);
});
test('hủy yêu cầu đang chạy (KPA_ABORT)', async () => {
  const b = boot((n, o) => new Promise((_, rej) => o.signal.addEventListener('abort', () => rej(new Error('aborted')))));
  const p = b.send(solve('abc')); await new Promise(r => setTimeout(r, 30));
  await b.send({ type: 'KPA_ABORT', id: 'abc' }); const r = await p; assert.equal(r.code, 'aborted');
});
test('từ chối người gửi lạ / trang không phải Khan / đầu vào quá dài', async () => {
  const b = boot(async () => OK);
  assert.equal(await b.send(solve(), { id: 'evil', tab: { url: 'https://www.khanacademy.org/' } }), 'no-response');
  assert.equal(await b.send(solve(), { id: 'me', tab: { url: 'https://evil.example/khanacademy.org/' } }), 'no-response');
  assert.equal(await b.send({ ...solve(), user: 'x'.repeat(15000) }).then(r => r.code), 'bad_input');
  assert.equal(await b.send({ type: 'KPA_TEST' }), 'no-response'); // KPA_TEST chỉ từ trang cài đặt
  assert.equal(b.calls.length, 0);
});
