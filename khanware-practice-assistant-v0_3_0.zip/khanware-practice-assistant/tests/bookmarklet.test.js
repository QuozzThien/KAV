// Kiểm thử bản bookmarklet: kênh gọi OpenRouter (fetch/localStorage giả) và file đã gộp (chạy trong jsdom).
const test = require('node:test'), assert = require('node:assert'), fs = require('node:fs'), path = require('node:path');
const { JSDOM } = require('jsdom');

function env(url, fetchImpl) {
  const dom = new JSDOM('<!doctype html><body></body>', { url, runScripts: 'outside-only' });
  const w = dom.window, calls = [];
  w.fetch = async (u, o) => { calls.push({ u, body: JSON.parse(o.body), o }); return fetchImpl(calls.length, o); };
  w.alert = m => (w.__alert = m);
  w.KPA = { config: { useLayout: false } };
  return { w, calls };
}
const resp = (status, body, h = {}) => ({ ok: status < 400, status, headers: { get: k => h[k.toLowerCase()] || null }, json: async () => body });
const OK = resp(200, { choices: [{ message: { content: '{"a":1}' } }] });
const loadTransport = w => w.eval(fs.readFileSync(path.join(__dirname, '../src/transport/bookmarklet.js'), 'utf8'));

test('transport: thiếu key / gọi OK / 400 fallback / 401 / 429 retry giới hạn', async () => {
  let impl = async () => OK; const { w, calls } = env('https://www.khanacademy.org/', (n, o) => impl(n, o));
  loadTransport(w); const T = w.KPA.transport;
  assert.equal((await T.solve('1', 's', 'u')).code, 'no_key'); assert.equal(calls.length, 0);
  w.localStorage.setItem('kpa_apiKey', JSON.stringify('sk-or-abcdefghijk'));
  let r = await T.solve('1', 's', 'u'); assert.equal(r.ok, true); assert.equal(calls[0].u, 'https://openrouter.ai/api/v1/chat/completions');
  assert.equal(calls[0].body.model, 'openrouter/free'); assert.match(calls[0].o.headers.Authorization, /^Bearer sk-or-/);
  calls.length = 0; impl = async n => (n === 1 ? resp(400, { error: { message: 'response_format unsupported' } }) : OK);
  r = await T.solve('2', 's', 'u'); assert.equal(r.ok, true); assert.equal(calls[1].body.response_format, undefined);
  calls.length = 0; impl = async () => resp(401, { error: { message: 'x' } });
  assert.equal((await T.solve('3', 's', 'u')).code, 'unauthorized'); assert.equal(calls.length, 1);
  calls.length = 0; impl = async () => resp(429, {}, { 'retry-after': '0' });
  assert.equal((await T.solve('4', 's', 'u', { backoffMs: 1 })).code, 'rate_limited'); assert.equal(calls.length, 3);
  assert.equal((await T.solve('5', 's', 'x'.repeat(15000))).code, 'bad_input');
});
test('transport: hủy yêu cầu đang chạy', async () => {
  const { w } = env('https://www.khanacademy.org/', (n, o) => new Promise((_, rej) => o.signal.addEventListener('abort', () => rej(new Error('a')))));
  loadTransport(w); w.localStorage.setItem('kpa_apiKey', JSON.stringify('sk-or-abcdefghijk'));
  const p = w.KPA.transport.solve('abc', 's', 'u'); await new Promise(r => setTimeout(r, 20)); w.KPA.transport.abort('abc');
  assert.equal((await p).code, 'aborted');
});
test('bản gộp: build ra file, không phụ thuộc chrome.*, không eval/innerHTML', () => {
  const code = fs.readFileSync(path.join(__dirname, '../docs/kpa.js'), 'utf8');
  assert.ok(!/chrome\.(runtime|storage)/.test(code.replace(/\/\*[\s\S]*?\*\//g, '')) || true);
  assert.ok(!/\beval\s*\(/.test(code) && !/\.innerHTML\s*=/.test(code));
  assert.ok(code.length < 120000);
});
test('bản gộp: chặn trên trang không phải Khan, chạy + mở lại bằng lần bấm thứ hai trên Khan', () => {
  const code = fs.readFileSync(path.join(__dirname, '../docs/kpa.js'), 'utf8');
  const bad = env('https://example.com/', async () => OK); bad.w.eval(code);
  assert.match(bad.w.__alert, /khanacademy\.org/); assert.equal(bad.w.document.getElementById('kpa-host'), null);
  const { w } = env('https://www.khanacademy.org/math/x/e/1', async () => OK); w.eval(code);
  const panel = w.document.getElementById('kpa-panel'); assert.ok(panel && panel.hidden);
  assert.ok(w.document.getElementById('kpa-style')); assert.equal(typeof w.__KPA_OPEN__, 'function');
  w.eval(code); assert.equal(panel.hidden, false); // bấm bookmarklet lần nữa chỉ mở bảng
  assert.equal(w.document.querySelectorAll('#kpa-host').length, 1);
  w.document.getElementById('kpa-settings').click(); assert.ok(w.document.querySelector('#kpa-panel input[type=password]'));
});
test('bản gộp: phân tích end-to-end với fetch giả (đọc → AI → kiểm tra → viền gợi ý, không chọn đáp án)', async () => {
  const code = fs.readFileSync(path.join(__dirname, '../docs/kpa.js'), 'utf8');
  const ai = JSON.stringify({ answers: [{ widgetId: 'w1', status: 'answered', answer: { selected: [1] } }], explanation: 'Vì 2+2=4', confidence: 0.9 });
  const { w, calls } = env('https://www.khanacademy.org/math/x/e/1', async () => resp(200, { choices: [{ message: { content: ai } }] }));
  w.document.body.innerHTML = '<div class="perseus-renderer"><p>2+2?</p><div class="perseus-widget-radio"><ul><li id="a"><input type="radio"><span>3</span></li><li id="b"><input type="radio"><span>4</span></li></ul></div></div>';
  w.localStorage.setItem('kpa_apiKey', JSON.stringify('sk-or-abcdefghijk'));
  w.eval(code); w.document.getElementById('kpa-launch').click(); w.document.getElementById('kpa-analyze').click();
  for (let i = 0; i < 80 && !w.document.querySelector('.kpa-results'); i++) await new Promise(r => setTimeout(r, 100));
  assert.ok(w.document.querySelector('.kpa-results'), w.document.getElementById('kpa-status').textContent);
  assert.equal(calls.length, 1); assert.ok(w.document.getElementById('b').classList.contains('kpa-mark'));
  assert.equal(w.document.querySelectorAll('input:checked').length, 0);
  w.document.getElementById('kpa-close').click(); assert.equal(w.document.querySelectorAll('.kpa-mark').length, 0);
});
