const test = require('node:test'), assert = require('node:assert');
const load = require('./helpers');
const page = '<div class="perseus-renderer"><p>2+2?</p><div class="perseus-widget-radio"><ul><li id="o0"><input type="radio"><span>3</span></li><li id="o1"><input type="radio"><span>4</span></li></ul></div></div>';

test('renderer: XSS từ AI hiển thị như chữ, không thành HTML', () => {
  const { K, doc } = load('');
  const v = { results: [{ widgetId: 'w1', type: 'expression', lines: ['<img src=x onerror=alert(1)>'], marks: [] }], explanation: '<script>alert(1)</script>', confidence: .5, needsMoreInfo: false };
  const node = K.renderer.buildResultNode(doc, v); doc.body.append(node);
  assert.equal(doc.querySelectorAll('img,script').length, 0);
  assert.ok(node.textContent.includes('<img src=x onerror=alert(1)>'));
});
test('renderer: chỉ thêm class viền, không đổi nội dung/giá trị/chọn của widget', () => {
  const { K, doc } = load(page);
  const read = K.reader.read(), before = doc.body.innerHTML.replace(/ class="kpa-mark"/g, '');
  const v = K.responseParser.validate({ answers: [{ widgetId: 'w1', status: 'answered', answer: { selected: [1] } }] }, read.exercise);
  assert.equal(K.renderer.applyMarks(read.refs, v), 1);
  assert.ok(doc.getElementById('o1').classList.contains('kpa-mark'));
  assert.equal(doc.querySelectorAll('input:checked').length, 0);
  assert.equal(doc.body.innerHTML.replace(/ class="kpa-mark"/g, ''), before);
  K.renderer.clearMarks(); assert.equal(doc.querySelectorAll('.kpa-mark').length, 0);
});
test('renderer: textSummary & bảng', () => {
  const { K, doc } = load('');
  const v = { results: [{ widgetId: 'w1', type: 'table', lines: [], marks: [], table: [{ row: 1, col: 1, value: '5' }] }], explanation: 'ok', confidence: null, needsMoreInfo: false };
  assert.match(K.renderer.textSummary(v), /Hàng 2, cột 2: 5/);
  assert.equal(K.renderer.buildResultNode(doc, v).querySelectorAll('table td').length, 2);
});
