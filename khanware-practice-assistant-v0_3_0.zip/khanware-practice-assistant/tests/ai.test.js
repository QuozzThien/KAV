const test = require('node:test'), assert = require('node:assert');
const load = require('./helpers');
const page = '<div class="perseus-renderer"><p>2+2?</p><div class="perseus-widget-radio"><ul><li><input type="radio"><span>3</span></li><li><input type="radio"><span>4</span></li></ul></div></div>';

test('extractJson: thuần, có fence, có chữ thừa, JSON lỗi', () => {
  const { K } = load(''); const P = K.responseParser;
  assert.deepEqual(P.extractJson('{"a":1}'), { a: 1 });
  assert.deepEqual(P.extractJson('```json\n{"a":1}\n```'), { a: 1 });
  assert.deepEqual(P.extractJson('Đây: {"a":"}{","b":{"c":2}} hết'), { a: '}{', b: { c: 2 } });
  assert.throws(() => P.extractJson('không có json'));
  assert.throws(() => P.extractJson('{"a":'));
});
test('promptBuilder: chứa định dạng, từ chối câu chưa đủ, giới hạn kích thước', () => {
  const { K } = load(page);
  const ex = K.reader.read().exercise, p = K.promptBuilder.build(ex);
  assert.ok(p.user.includes('selected') && p.user.includes('"id":"w1"') && !p.user.includes('apiKey'));
  assert.ok(K.promptBuilder.build({ status: 'unsupported' }).error);
  const big = JSON.parse(JSON.stringify(ex)); big.questionText = 'x'.repeat(13000);
  assert.ok(K.promptBuilder.build(big).error);
});
test('validate: chấp nhận đáp án hợp lệ và dựng hiển thị', () => {
  const { K } = load(page); const ex = K.reader.read().exercise;
  const v = K.responseParser.validate({ answers: [{ widgetId: 'w1', status: 'answered', answer: { selected: [1] } }], explanation: 'Vì 2+2=4', confidence: '85' }, ex);
  assert.equal(v.ok, true); assert.deepEqual(v.results[0].marks, [1]); assert.match(v.results[0].lines[0], /4$/);
  assert.equal(v.confidence, .85);
});
test('validate: loại phản hồi sai cấu trúc / chỉ số bịa / thiếu widget / insufficient', () => {
  const { K } = load(page); const ex = K.reader.read().exercise, V = K.responseParser.validate;
  assert.equal(V(null, ex).ok, false);
  assert.equal(V({ answers: [] }, ex).ok, false);
  assert.equal(V({ answers: [{ widgetId: 'w1', status: 'answered', answer: { selected: [9] } }] }, ex).ok, false);
  assert.equal(V({ answers: [{ widgetId: 'w9', answer: { selected: [0] } }] }, ex).ok, false);
  const ins = V({ answers: [{ widgetId: 'w1', status: 'insufficient_data' }] }, ex);
  assert.equal(ins.ok, true); assert.equal(ins.needsMoreInfo, true); assert.equal(ins.results[0].insufficient, true);
});
test('normConfidence', () => {
  const { K } = load(''); const n = K.responseParser.normConfidence;
  assert.equal(n(.7), .7); assert.equal(n(70), .7); assert.equal(n('high'), .85); assert.equal(n('???'), null); assert.equal(n(-1), 0);
});
